var annotated_dup =
[
    [ "DPB_I2cSensors", "struct_d_p_b___i2c_sensors.html", "struct_d_p_b___i2c_sensors" ],
    [ "I2cDevice", "struct_i2c_device.html", "struct_i2c_device" ],
    [ "periodic_info", "structperiodic__info.html", "structperiodic__info" ],
    [ "wrapper", "structwrapper.html", "structwrapper" ]
];