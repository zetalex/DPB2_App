var i2c_8c =
[
    [ "i2c_mask_reg", "i2c_8c.html#a2e4bb76a85aec1ad51ce7c6b0086d927", null ],
    [ "i2c_read", "i2c_8c.html#a73331be202cee1b3031fc730a21c40fd", null ],
    [ "i2c_read_reg", "i2c_8c.html#a4f020e80dcaf91514323406ede21dfe7", null ],
    [ "i2c_readn_reg", "i2c_8c.html#a29b0bc859d2e1cf176d899f4d252b83e", null ],
    [ "i2c_start", "i2c_8c.html#a4a31f20e730ca85d96ff3c488ba06920", null ],
    [ "i2c_stop", "i2c_8c.html#aa7031b091ba2781263f36a0801f9bc5f", null ],
    [ "i2c_write", "i2c_8c.html#ae32f803b20cf266f1d8c7757930556a3", null ],
    [ "i2c_write_reg", "i2c_8c.html#a3bd3db6a03dd550e9484fd7e1b58b698", null ],
    [ "i2c_writen_reg", "i2c_8c.html#a668491241034adefc9aa5b440f3828db", null ]
];