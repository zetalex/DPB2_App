var group___s_f_p___masks =
[
    [ "alarms_mask", "group___s_f_p___masks.html#gaad33f84eb78e9bffe198abd176363cf7", null ],
    [ "status_mask", "group___s_f_p___masks.html#ga9ce4abbef051d812c72e5ede57b8ad5b", null ]
];