var timer_8c =
[
    [ "make_periodic", "timer_8c.html#a011f0be95c8fc6074964582116b9c772", null ],
    [ "wait_period", "timer_8c.html#af51864a19e81c743de094960aacfd4ab", null ]
];