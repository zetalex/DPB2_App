var group__err =
[
    [ "EINCMD", "group__err.html#gad51576999e1459fee4bd90c45e64a387", null ],
    [ "ERRREAD", "group__err.html#ga350584b5c661452d803c76862604246c", null ],
    [ "ERRSET", "group__err.html#ga23efd3761fef533bafef298dbc0300f7", null ]
];