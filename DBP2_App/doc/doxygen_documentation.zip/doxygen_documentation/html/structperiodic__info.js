var structperiodic__info =
[
    [ "alarm_sig", "structperiodic__info.html#a8a90a0351e9b0e46f86f7e4fac065c52", null ],
    [ "sig", "structperiodic__info.html#a68be1f65e6d1f2949835d9b6b44bcf8e", null ]
];