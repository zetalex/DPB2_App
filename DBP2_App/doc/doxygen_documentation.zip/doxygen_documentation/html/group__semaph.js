var group__semaph =
[
    [ "alarm_sync", "group__semaph.html#gaeb5a5fea0af375a65ccc38e0b448c865", null ],
    [ "file_sync", "group__semaph.html#gaedd23a63122331007c8bf5012ceee410", null ],
    [ "i2c_sync", "group__semaph.html#gac8fcd47b1b961d741f7ce6363aa29fe3", null ],
    [ "sem_valid", "group__semaph.html#gad943d7982d50f019bd63722382aeac52", null ],
    [ "thread_sync", "group__semaph.html#ga4e56da6bdcd1fe995892ac706b3f6914", null ]
];