var searchData=
[
  ['local_20semaphores_0',['Local Semaphores',['../group__semaph.html',1,'']]]
];
