var searchData=
[
  ['zmq_5fcontext_0',['zmq_context',['../main_8c.html#a4003bd20ad7e23891f5fbf3c4cb69171',1,'main.c']]]
];
