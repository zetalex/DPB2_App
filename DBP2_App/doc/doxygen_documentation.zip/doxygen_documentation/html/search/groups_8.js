var searchData=
[
  ['semaphores_0',['Local Semaphores',['../group__semaph.html',1,'']]],
  ['sfp_20alarms_20masks_1',['SFP Alarms Masks',['../group___s_f_p___masks.html',1,'']]],
  ['shared_20memory_2',['Shared Memory',['../group__shm.html',1,'']]]
];
