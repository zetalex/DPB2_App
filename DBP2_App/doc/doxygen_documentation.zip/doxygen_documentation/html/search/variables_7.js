var searchData=
[
  ['i2c_5fsync_0',['i2c_sync',['../group__semaph.html#gac8fcd47b1b961d741f7ce6363aa29fe3',1,'main.c']]]
];
