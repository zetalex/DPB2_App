var searchData=
[
  ['gen_5fuuid_0',['gen_uuid',['../main_8c.html#a911ad40973d7e53741d45db3d851edab',1,'main.c']]],
  ['get_5fgpio_5fbase_5faddress_1',['get_GPIO_base_address',['../main_8c.html#a52a0fb3b674daae49dcc57dd6d7e0a18',1,'main.c']]],
  ['gpio_20pins_2',['GPIO pins',['../group___g_p_i_o.html',1,'']]],
  ['gpio_5fbase_5faddress_3',['GPIO_BASE_ADDRESS',['../constants_8h.html#aef5891908061c19e15f123a681aa25d0',1,'constants.h']]],
  ['gpio_5fpins_4',['GPIO_PINS',['../group___g_p_i_o.html#gacfe9d6039c7fb650da2399441be1a582',1,'constants.h']]],
  ['gpio_5fpins_5fsize_5',['GPIO_PINS_SIZE',['../group___g_p_i_o.html#ga730d3a13ebea433d4ac7004d125362d8',1,'constants.h']]]
];
