var searchData=
[
  ['dig_5fcommand_5fhandling_0',['dig_command_handling',['../main_8c.html#a84634466dbde056f23c967b97f949f85',1,'main.c']]],
  ['dpb_5fcommand_5fhandling_1',['dpb_command_handling',['../main_8c.html#ae7a88328289bc28c155d26c1c5557b95',1,'main.c']]]
];
