var searchData=
[
  ['dig_5fcommand_5fhandling_0',['dig_command_handling',['../main_8c.html#a84634466dbde056f23c967b97f949f85',1,'main.c']]],
  ['dpb_5fcommand_5fhandling_1',['dpb_command_handling',['../main_8c.html#acbb749d081a4ce144ddffd2fe8274d01',1,'main.c']]]
];
