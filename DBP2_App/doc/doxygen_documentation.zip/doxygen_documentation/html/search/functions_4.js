var searchData=
[
  ['gen_5fuuid_0',['gen_uuid',['../main_8c.html#a911ad40973d7e53741d45db3d851edab',1,'main.c']]],
  ['get_5fgpio_5fbase_5faddress_1',['get_GPIO_base_address',['../main_8c.html#a52a0fb3b674daae49dcc57dd6d7e0a18',1,'main.c']]]
];
