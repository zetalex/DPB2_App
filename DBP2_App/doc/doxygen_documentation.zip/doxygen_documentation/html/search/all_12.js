var searchData=
[
  ['xlnx_5fams_5fread_5ftemp_0',['xlnx_ams_read_temp',['../main_8c.html#a94d6bc980d1879063d3ff01122189995',1,'main.c']]],
  ['xlnx_5fams_5fread_5fvolt_1',['xlnx_ams_read_volt',['../main_8c.html#a8285558c52e445f95c90968e60ba1f2b',1,'main.c']]],
  ['xlnx_5fams_5fset_5flimits_2',['xlnx_ams_set_limits',['../main_8c.html#a353ce19623b2277870f0289c9a2f76ba',1,'main.c']]]
];
