var searchData=
[
  ['zmq_5fsocket_5finit_0',['zmq_socket_init',['../main_8c.html#a017c111b6b069aff7fb3d5cc6091575c',1,'main.c']]]
];
