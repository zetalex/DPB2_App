var searchData=
[
  ['json_5fschema_5fvalidate_0',['json_schema_validate',['../main_8c.html#ac1bae33fb76086f00eb915f1477c15ee',1,'main.c']]]
];
