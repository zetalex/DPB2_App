var searchData=
[
  ['alarm_5fjson_0',['alarm_json',['../main_8c.html#afa69f048a25258ccb54cf53eb5f8ccc0',1,'main.c']]],
  ['atexit_5ffunction_1',['atexit_function',['../main_8c.html#a00dd035255224ec7702727251ca54552',1,'main.c']]],
  ['aurora_5fdown_5falarm_2',['aurora_down_alarm',['../main_8c.html#a3ab8810c7a9f27237b8da1f43d1d1039',1,'main.c']]]
];
