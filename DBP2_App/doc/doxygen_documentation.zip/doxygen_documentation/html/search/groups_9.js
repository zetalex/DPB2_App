var searchData=
[
  ['threads_0',['Child process and threads',['../group__pth.html',1,'']]]
];
