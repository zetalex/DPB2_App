var searchData=
[
  ['zmq_5fcontext_0',['zmq_context',['../main_8c.html#a4003bd20ad7e23891f5fbf3c4cb69171',1,'main.c']]],
  ['zmq_5fsocket_5finit_1',['zmq_socket_init',['../main_8c.html#a017c111b6b069aff7fb3d5cc6091575c',1,'main.c']]]
];
