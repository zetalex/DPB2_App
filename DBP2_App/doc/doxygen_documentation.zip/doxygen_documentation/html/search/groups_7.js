var searchData=
[
  ['pins_0',['GPIO pins',['../group___g_p_i_o.html',1,'']]],
  ['process_20and_20threads_1',['Child process and threads',['../group__pth.html',1,'']]]
];
