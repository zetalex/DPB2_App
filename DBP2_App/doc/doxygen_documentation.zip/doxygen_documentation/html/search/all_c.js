var searchData=
[
  ['parsing_5fmon_5fsensor_5fdata_5finto_5farray_0',['parsing_mon_sensor_data_into_array',['../main_8c.html#afca6f4b199a429b21aaecf5e7bddd4a2',1,'main.c']]],
  ['parsing_5fmon_5fstatus_5fdata_5finto_5farray_1',['parsing_mon_status_data_into_array',['../main_8c.html#a15944c0c5812a5c6d05ca87cf607f210',1,'main.c']]],
  ['periodic_5finfo_2',['periodic_info',['../structperiodic__info.html',1,'']]],
  ['pins_3',['GPIO pins',['../group___g_p_i_o.html',1,'']]],
  ['process_20and_20threads_4',['Child process and threads',['../group__pth.html',1,'']]]
];
