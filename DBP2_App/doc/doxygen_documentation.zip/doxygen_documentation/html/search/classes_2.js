var searchData=
[
  ['periodic_5finfo_0',['periodic_info',['../structperiodic__info.html',1,'']]]
];
