var searchData=
[
  ['eth_5fdown_5falarm_0',['eth_down_alarm',['../main_8c.html#a60ce97205772d906f1e6e02c88e75edf',1,'main.c']]],
  ['eth_5flink_5fstatus_1',['eth_link_status',['../main_8c.html#aab9bb1efa1395ed5009cda09bcbfc72d',1,'main.c']]],
  ['eth_5flink_5fstatus_5fconfig_2',['eth_link_status_config',['../main_8c.html#a0d290e59e0c318845088fbea23b7a485',1,'main.c']]]
];
