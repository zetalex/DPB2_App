var structwrapper =
[
    [ "ams_sync", "structwrapper.html#a05f631f56238f27397efe06a385b8d85", null ],
    [ "ch_type", "structwrapper.html#a29abc8acc94605c7983339dc56f5acd5", null ],
    [ "chn", "structwrapper.html#a834cb2f99c772a9508188ea1a5cf3469", null ],
    [ "empty", "structwrapper.html#a0096ed68692b83dac0d5cf7cf780ad49", null ],
    [ "ev_type", "structwrapper.html#aa9d80fe477937f04be6dffb99152e581", null ],
    [ "full", "structwrapper.html#a25875c11ed23317723b25d45f3f4a293", null ],
    [ "tmpstmp", "structwrapper.html#a67f7ed65d472f9ad0528f0dea8fbd63e", null ]
];