var timer_8h =
[
    [ "periodic_info", "structperiodic__info.html", "structperiodic__info" ],
    [ "make_periodic", "timer_8h.html#a011f0be95c8fc6074964582116b9c772", null ],
    [ "wait_period", "timer_8h.html#af51864a19e81c743de094960aacfd4ab", null ]
];