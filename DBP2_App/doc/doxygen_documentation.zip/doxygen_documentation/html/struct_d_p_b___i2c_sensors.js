var struct_d_p_b___i2c_sensors =
[
    [ "dev_pcb_temp", "struct_d_p_b___i2c_sensors.html#a01aa6a9d433c9942e7944feeebbe8cc8", null ],
    [ "dev_sfp0_2_volt", "struct_d_p_b___i2c_sensors.html#a365423ef56d70f018dc389db063c3863", null ],
    [ "dev_sfp0_A0", "struct_d_p_b___i2c_sensors.html#ad4406063845487f0a645365be434bdad", null ],
    [ "dev_sfp0_A2", "struct_d_p_b___i2c_sensors.html#aa010a1949e8479a16d28badcdb3adb33", null ],
    [ "dev_sfp1_A0", "struct_d_p_b___i2c_sensors.html#aeb394431ec8f3142dd028cbbe8795948", null ],
    [ "dev_sfp1_A2", "struct_d_p_b___i2c_sensors.html#ab15594625d35f0ce4c3665b634a0d82a", null ],
    [ "dev_sfp2_A0", "struct_d_p_b___i2c_sensors.html#a5c73d4ac3d1ebb4d379064a8ca5eaf99", null ],
    [ "dev_sfp2_A2", "struct_d_p_b___i2c_sensors.html#aa956bbe3b5017408ed995a7f78dc3b1a", null ],
    [ "dev_sfp3_5_volt", "struct_d_p_b___i2c_sensors.html#a3b0d1e4e62a4dcafc456afe059a6e75f", null ],
    [ "dev_sfp3_A0", "struct_d_p_b___i2c_sensors.html#ab9d5b20174fdce0b416192c4d260309e", null ],
    [ "dev_sfp3_A2", "struct_d_p_b___i2c_sensors.html#a93575a1d1d8f441a5e9a856eafa1b127", null ],
    [ "dev_sfp4_A0", "struct_d_p_b___i2c_sensors.html#a50bcc49bed9bb747749a1aa0f07a79d6", null ],
    [ "dev_sfp4_A2", "struct_d_p_b___i2c_sensors.html#a9c6d15e6fa4d25b82a3e041e327b8e83", null ],
    [ "dev_sfp5_A0", "struct_d_p_b___i2c_sensors.html#a3ecc82cccbfd471a4a2a4a8e213e0f5a", null ],
    [ "dev_sfp5_A2", "struct_d_p_b___i2c_sensors.html#a9e3bedba01d441710ae0b7d7243b054d", null ],
    [ "dev_som_volt", "struct_d_p_b___i2c_sensors.html#a60181c40b19a7a03dac3cb3088376687", null ]
];