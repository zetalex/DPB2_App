var topics =
[
    [ "Custom Error Flags", "group__err.html", "group__err" ],
    [ "SFP Alarms Masks", "group___s_f_p___masks.html", "group___s_f_p___masks" ],
    [ "GPIO pins", "group___g_p_i_o.html", "group___g_p_i_o" ],
    [ "Shared Memory", "group__shm.html", "group__shm" ],
    [ "Local Semaphores", "group__semaph.html", "group__semaph" ],
    [ "Child process and threads", "group__pth.html", "group__pth" ]
];