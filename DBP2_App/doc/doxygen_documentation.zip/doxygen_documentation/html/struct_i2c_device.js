var struct_i2c_device =
[
    [ "addr", "struct_i2c_device.html#a41a6aad09727eb120338c35535a652a6", null ],
    [ "fd", "struct_i2c_device.html#a6f8059414f0228f0256115e024eeed4b", null ],
    [ "filename", "struct_i2c_device.html#aeac90097f29f7529968697163cea5c18", null ]
];